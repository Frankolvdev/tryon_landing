"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import styles from "./fashion-constellation-widget.module.css";

type FashionNode = {
  id: string;
  label: string;
  meta: string;
  image: string;
  className: string;
};

const nodes: FashionNode[] = [
  {
    id: "dress",
    label: "Vestidos",
    meta: "12.4k variantes",
    image: "/images/landing/trust/scene/dress.webp",
    className: "nodeDress",
  },
  {
    id: "jacket",
    label: "Chaquetas",
    meta: "8.9k combinaciones",
    image: "/images/landing/trust/scene/jacket.webp",
    className: "nodeJacket",
  },
  {
    id: "shorts",
    label: "Bottoms",
    meta: "10.7k estilos",
    image: "/images/landing/trust/scene/shorts.webp",
    className: "nodeShorts",
  },
  {
    id: "heels",
    label: "Calzado",
    meta: "6.3k ajustes",
    image: "/images/landing/trust/scene/heels.webp",
    className: "nodeHeels",
  },
] as const;

const phases = [
  "Mapeando estilo",
  "Conectando atributos",
  "Combinando prendas",
  "Aprendiendo preferencias",
] as const;

export function HolographicFashionScene() {
  const widgetRef = useRef<HTMLDivElement>(null);
  const [activeNode, setActiveNode] = useState(0);
  const [phase, setPhase] = useState(0);

  const particles = useMemo(
    () =>
      Array.from({ length: 28 }, (_, index) => ({
        id: index,
        left: `${6 + ((index * 41) % 88)}%`,
        top: `${7 + ((index * 67) % 84)}%`,
        delay: `${-((index % 9) * 0.42)}s`,
        duration: `${5.2 + (index % 7) * 0.55}s`,
        size: `${2 + (index % 3)}px`,
      })),
    [],
  );

  useEffect(() => {
    const nodeTimer = window.setInterval(() => {
      setActiveNode((current) => (current + 1) % nodes.length);
    }, 2600);

    const phaseTimer = window.setInterval(() => {
      setPhase((current) => (current + 1) % phases.length);
    }, 1850);

    return () => {
      window.clearInterval(nodeTimer);
      window.clearInterval(phaseTimer);
    };
  }, []);

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const element = widgetRef.current;
    if (!element) return;

    const bounds = element.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;

    element.style.setProperty("--pointer-x", `${x * 18}px`);
    element.style.setProperty("--pointer-y", `${y * 14}px`);
  };

  const resetPointer = () => {
    const element = widgetRef.current;
    if (!element) return;
    element.style.setProperty("--pointer-x", "0px");
    element.style.setProperty("--pointer-y", "0px");
  };

  return (
    <div
      ref={widgetRef}
      className={styles.widget}
      onPointerMove={handlePointerMove}
      onPointerLeave={resetPointer}
      aria-label="Constelación de moda conectada por inteligencia artificial"
    >
      <div className={styles.ambientGlow} aria-hidden="true" />

      <div className={styles.particles} aria-hidden="true">
        {particles.map((particle) => (
          <span
            key={particle.id}
            style={{
              left: particle.left,
              top: particle.top,
              width: particle.size,
              height: particle.size,
              animationDelay: particle.delay,
              animationDuration: particle.duration,
            }}
          />
        ))}
      </div>

      <svg className={styles.connections} viewBox="0 0 720 560" aria-hidden="true">
        <defs>
          <linearGradient id="constellation-line" x1="0" x2="1">
            <stop offset="0" stopColor="#47ccff" stopOpacity="0" />
            <stop offset="0.48" stopColor="#81e5ff" stopOpacity="0.75" />
            <stop offset="1" stopColor="#cf2449" stopOpacity="0" />
          </linearGradient>
          <filter id="constellation-glow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <path className={styles.lineOne} d="M360 278 C270 250 228 173 151 132" />
        <path className={styles.lineTwo} d="M360 278 C452 240 505 161 583 126" />
        <path className={styles.lineThree} d="M360 278 C275 322 239 412 158 440" />
        <path className={styles.lineFour} d="M360 278 C456 318 493 402 583 432" />
        <path className={styles.orbitLine} d="M111 282 C146 75 559 52 616 260 C660 425 485 510 321 494 C154 478 75 393 111 282Z" />
      </svg>

      <div className={styles.centerCluster} aria-hidden="true">
        <span className={styles.centerOrbitOne} />
        <span className={styles.centerOrbitTwo} />
        <span className={styles.centerPulse} />
        <div className={styles.core}>
          <span>AI</span>
          <small>STYLE GRAPH</small>
        </div>
      </div>

      {nodes.map((node, index) => (
        <button
          key={node.id}
          type="button"
          className={`${styles.node} ${styles[node.className]} ${index === activeNode ? styles.nodeActive : ""}`}
          onClick={() => setActiveNode(index)}
          aria-pressed={index === activeNode}
        >
          <span className={styles.nodeImageWrap}>
            <span
              className={styles.nodeImage}
              style={{ backgroundImage: `url(${node.image})` }}
              aria-hidden="true"
            />
          </span>
          <span className={styles.nodeCopy}>
            <strong>{node.label}</strong>
            <small>{node.meta}</small>
          </span>
          <i aria-hidden="true" />
        </button>
      ))}

      <div className={styles.microNodes} aria-hidden="true">
        {Array.from({ length: 12 }, (_, index) => (
          <span key={index} style={{ "--i": index } as React.CSSProperties} />
        ))}
      </div>

      <div className={styles.statusBar}>
        <span className={styles.liveDot} aria-hidden="true" />
        <div>
          <small>RED DE MODA EN TIEMPO REAL</small>
          <strong key={phases[phase]}>{phases[phase]}</strong>
        </div>
        <span className={styles.progress} aria-hidden="true"><i /></span>
        <b>{String((activeNode + 1) * 23 + 7).padStart(2, "0")}%</b>
      </div>
    </div>
  );
}
