"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

type GarmentKind = "dress" | "jacket" | "top" | "heels";

function hologramMaterial(color = 0xff3158, opacity = 0.5) {
  return new THREE.MeshPhysicalMaterial({
    color,
    emissive: color,
    emissiveIntensity: 1.15,
    metalness: 0.22,
    roughness: 0.3,
    transparent: true,
    opacity,
    transmission: 0.08,
    side: THREE.DoubleSide,
    depthWrite: true,
  });
}

function fashionMaterial(color: number) {
  return new THREE.MeshPhysicalMaterial({
    color,
    emissive: color,
    emissiveIntensity: 0.22,
    metalness: 0.48,
    roughness: 0.3,
    clearcoat: 0.65,
    clearcoatRoughness: 0.22,
    side: THREE.DoubleSide,
  });
}

function wireOverlay(mesh: THREE.Mesh, color = 0xff7890, opacity = 0.2) {
  const lines = new THREE.LineSegments(
    new THREE.WireframeGeometry(mesh.geometry),
    new THREE.LineBasicMaterial({ color, transparent: true, opacity, depthWrite: false }),
  );
  mesh.add(lines);
}

function capsuleBetween(
  radius: number,
  length: number,
  position: THREE.Vector3,
  rotation: THREE.Euler,
  material: THREE.Material,
) {
  const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 12, 20), material);
  mesh.position.copy(position);
  mesh.rotation.copy(rotation);
  return mesh;
}

function createFemaleHologram() {
  const group = new THREE.Group();
  group.name = "female-hologram";

  const bodyMaterial = hologramMaterial(0xff3158, 0.46);
  const accentMaterial = hologramMaterial(0x74cfff, 0.34);

  const torsoProfile = [
    new THREE.Vector2(0.34, -1.28),
    new THREE.Vector2(0.52, -1.06),
    new THREE.Vector2(0.58, -0.76),
    new THREE.Vector2(0.45, -0.42),
    new THREE.Vector2(0.42, -0.1),
    new THREE.Vector2(0.58, 0.28),
    new THREE.Vector2(0.7, 0.72),
    new THREE.Vector2(0.62, 1.08),
    new THREE.Vector2(0.34, 1.3),
  ];
  const torso = new THREE.Mesh(new THREE.LatheGeometry(torsoProfile, 48), bodyMaterial);
  torso.scale.z = 0.72;
  torso.position.y = 0.58;
  wireOverlay(torso, 0xff7892, 0.2);
  group.add(torso);

  const chestLeft = new THREE.Mesh(new THREE.SphereGeometry(0.36, 28, 20), bodyMaterial);
  chestLeft.scale.set(1, 0.8, 0.72);
  chestLeft.position.set(-0.25, 1.35, 0.19);
  const chestRight = chestLeft.clone();
  chestRight.position.x = 0.25;
  group.add(chestLeft, chestRight);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.21, 0.42, 24), bodyMaterial);
  neck.position.y = 2.1;
  group.add(neck);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.43, 40, 32), bodyMaterial);
  head.scale.set(0.82, 1.08, 0.78);
  head.position.y = 2.65;
  wireOverlay(head, 0x8ed8ff, 0.18);
  group.add(head);

  const jaw = new THREE.Mesh(new THREE.SphereGeometry(0.35, 28, 20), bodyMaterial);
  jaw.scale.set(0.85, 0.62, 0.76);
  jaw.position.set(0, 2.43, 0.03);
  group.add(jaw);

  const hair = new THREE.Mesh(
    new THREE.SphereGeometry(0.49, 34, 26, 0, Math.PI * 2, 0, Math.PI * 0.82),
    hologramMaterial(0x45b8ff, 0.25),
  );
  hair.scale.set(0.92, 1.15, 0.9);
  hair.position.set(0, 2.72, -0.08);
  group.add(hair);

  const ponytail = capsuleBetween(
    0.14,
    1.2,
    new THREE.Vector3(0.28, 2.1, -0.22),
    new THREE.Euler(0.18, 0, -0.28),
    accentMaterial,
  );
  group.add(ponytail);

  const shoulderL = new THREE.Mesh(new THREE.SphereGeometry(0.28, 24, 18), bodyMaterial);
  shoulderL.scale.set(1.18, 0.82, 0.85);
  shoulderL.position.set(-0.67, 1.55, 0);
  const shoulderR = shoulderL.clone();
  shoulderR.position.x = 0.67;
  group.add(shoulderL, shoulderR);

  const upperArmL = capsuleBetween(0.15, 0.92, new THREE.Vector3(-0.82, 0.94, 0.03), new THREE.Euler(0, 0, 0.15), bodyMaterial);
  const forearmL = capsuleBetween(0.12, 0.87, new THREE.Vector3(-0.91, 0.02, 0.1), new THREE.Euler(0.08, 0, 0.04), bodyMaterial);
  const upperArmR = capsuleBetween(0.15, 0.92, new THREE.Vector3(0.82, 0.94, 0.03), new THREE.Euler(0, 0, -0.15), bodyMaterial);
  const forearmR = capsuleBetween(0.12, 0.87, new THREE.Vector3(0.91, 0.02, 0.1), new THREE.Euler(0.08, 0, -0.04), bodyMaterial);
  group.add(upperArmL, forearmL, upperArmR, forearmR);

  [-1, 1].forEach((side) => {
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.14, 20, 14), bodyMaterial);
    hand.scale.set(0.72, 1.28, 0.5);
    hand.position.set(side * 0.93, -0.58, 0.14);
    group.add(hand);
  });

  const hipL = new THREE.Mesh(new THREE.SphereGeometry(0.4, 28, 20), bodyMaterial);
  hipL.scale.set(1.08, 0.82, 0.9);
  hipL.position.set(-0.32, -0.8, 0);
  const hipR = hipL.clone();
  hipR.position.x = 0.32;
  group.add(hipL, hipR);

  const thighL = capsuleBetween(0.23, 1.22, new THREE.Vector3(-0.3, -1.67, 0), new THREE.Euler(0.02, 0, 0.025), bodyMaterial);
  const shinL = capsuleBetween(0.16, 1.3, new THREE.Vector3(-0.31, -2.86, 0.03), new THREE.Euler(0.03, 0, 0.01), bodyMaterial);
  const thighR = capsuleBetween(0.23, 1.22, new THREE.Vector3(0.3, -1.67, 0), new THREE.Euler(0.02, 0, -0.025), bodyMaterial);
  const shinR = capsuleBetween(0.16, 1.3, new THREE.Vector3(0.31, -2.86, 0.03), new THREE.Euler(0.03, 0, -0.01), bodyMaterial);
  group.add(thighL, shinL, thighR, shinR);

  [-1, 1].forEach((side) => {
    const foot = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.42, 10, 18), bodyMaterial);
    foot.rotation.x = Math.PI / 2.15;
    foot.position.set(side * 0.31, -3.62, 0.18);
    foot.scale.z = 0.72;
    group.add(foot);
  });

  const scan = new THREE.Mesh(
    new THREE.CylinderGeometry(1.03, 1.03, 0.026, 64, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0x9fe4ff,
      transparent: true,
      opacity: 0.92,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }),
  );
  scan.name = "scan-ring";
  group.add(scan);

  return group;
}

function addEdgeGlow(mesh: THREE.Mesh, color: number) {
  const edge = new THREE.LineSegments(
    new THREE.EdgesGeometry(mesh.geometry, 18),
    new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.78 }),
  );
  mesh.add(edge);
}

function createDress(color: number) {
  const group = new THREE.Group();
  const material = fashionMaterial(color);
  const bodiceProfile = [
    new THREE.Vector2(0.28, -0.55),
    new THREE.Vector2(0.38, -0.28),
    new THREE.Vector2(0.44, 0.12),
    new THREE.Vector2(0.34, 0.5),
  ];
  const bodice = new THREE.Mesh(new THREE.LatheGeometry(bodiceProfile, 36), material);
  bodice.scale.z = 0.65;
  bodice.position.y = 0.52;
  addEdgeGlow(bodice, 0xff9aad);
  group.add(bodice);

  const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.92, 1.45, 48, 7, true), material);
  skirt.position.y = -0.52;
  skirt.scale.z = 0.72;
  addEdgeGlow(skirt, color);
  group.add(skirt);

  const belt = new THREE.Mesh(new THREE.TorusGeometry(0.43, 0.045, 10, 48), fashionMaterial(0xf3b3c1));
  belt.rotation.x = Math.PI / 2;
  belt.position.y = 0.05;
  group.add(belt);

  [-1, 1].forEach((side) => {
    const strap = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.55, 0.06), material);
    strap.position.set(side * 0.25, 0.96, 0.02);
    strap.rotation.z = side * 0.16;
    group.add(strap);
  });
  return group;
}

function createTop(color: number) {
  const group = new THREE.Group();
  const material = fashionMaterial(color);
  const profile = [
    new THREE.Vector2(0.31, -0.45),
    new THREE.Vector2(0.43, -0.18),
    new THREE.Vector2(0.48, 0.18),
    new THREE.Vector2(0.35, 0.52),
  ];
  const shell = new THREE.Mesh(new THREE.LatheGeometry(profile, 40), material);
  shell.scale.z = 0.68;
  addEdgeGlow(shell, 0xa9e6ff);
  group.add(shell);

  const neck = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.04, 10, 40, Math.PI), material);
  neck.rotation.x = Math.PI / 2;
  neck.rotation.z = Math.PI;
  neck.position.set(0, 0.48, 0.26);
  group.add(neck);
  return group;
}

function createJacket(color: number) {
  const group = new THREE.Group();
  const material = fashionMaterial(color);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.54, 0.48, 1.15, 38, 4, true), material);
  body.scale.z = 0.68;
  addEdgeGlow(body, 0xb7e7ff);
  group.add(body);

  [-1, 1].forEach((side) => {
    const sleeve = new THREE.Mesh(new THREE.CapsuleGeometry(0.17, 0.86, 10, 18), material);
    sleeve.position.set(side * 0.64, -0.06, 0);
    sleeve.rotation.z = side * 0.22;
    addEdgeGlow(sleeve, color);
    group.add(sleeve);
  });

  const lapelGeometry = new THREE.ShapeGeometry(
    (() => {
      const s = new THREE.Shape();
      s.moveTo(0, 0.48);
      s.lineTo(0.3, 0.12);
      s.lineTo(0.12, -0.12);
      s.lineTo(0, 0.08);
      s.closePath();
      return s;
    })(),
  );
  [-1, 1].forEach((side) => {
    const lapel = new THREE.Mesh(lapelGeometry, fashionMaterial(0x9ddcff));
    lapel.position.set(side * 0.03, 0.1, 0.39);
    lapel.scale.x = side;
    group.add(lapel);
  });
  return group;
}

function createHeels(color: number) {
  const group = new THREE.Group();
  const material = fashionMaterial(color);
  [-1, 1].forEach((side) => {
    const shoe = new THREE.Mesh(new THREE.CapsuleGeometry(0.17, 0.5, 10, 18), material);
    shoe.rotation.x = Math.PI / 2;
    shoe.scale.set(1, 0.72, 0.72);
    shoe.position.set(side * 0.32, 0, 0.12);
    addEdgeGlow(shoe, color);
    group.add(shoe);

    const heel = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.055, 0.48, 12), material);
    heel.position.set(side * 0.32, -0.28, -0.12);
    heel.rotation.x = -0.1;
    group.add(heel);
  });
  return group;
}

function createGarment(kind: GarmentKind, color: number) {
  const group =
    kind === "dress"
      ? createDress(color)
      : kind === "jacket"
        ? createJacket(color)
        : kind === "top"
          ? createTop(color)
          : createHeels(color);

  const halo = new THREE.Mesh(
    new THREE.TorusGeometry(0.9, 0.018, 8, 72),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.32, depthWrite: false }),
  );
  halo.rotation.x = Math.PI / 2;
  halo.position.y = -0.1;
  group.add(halo);
  return group;
}

export function HolographicFashionScene() {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
    camera.position.set(0, 0.05, 10.2);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.8));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    mount.appendChild(renderer.domElement);

    const root = new THREE.Group();
    root.rotation.x = -0.025;
    scene.add(root);

    const mannequin = createFemaleHologram();
    mannequin.scale.setScalar(0.87);
    mannequin.position.y = 0.12;
    root.add(mannequin);

    const platform = new THREE.Mesh(
      new THREE.CylinderGeometry(1.55, 1.82, 0.16, 72),
      new THREE.MeshPhysicalMaterial({
        color: 0x16050b,
        emissive: 0xff2047,
        emissiveIntensity: 0.9,
        metalness: 0.82,
        roughness: 0.2,
        transparent: true,
        opacity: 0.74,
      }),
    );
    platform.position.y = -3.5;
    root.add(platform);

    const platformRing = new THREE.Mesh(
      new THREE.TorusGeometry(1.68, 0.035, 12, 96),
      new THREE.MeshBasicMaterial({ color: 0x67caff, transparent: true, opacity: 0.88 }),
    );
    platformRing.rotation.x = Math.PI / 2;
    platformRing.position.y = -3.4;
    root.add(platformRing);

    const orbitRings: THREE.Mesh[] = [];
    [2.15, 2.75].forEach((radius, index) => {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(radius, 0.014, 8, 144),
        new THREE.MeshBasicMaterial({
          color: index === 0 ? 0xff335a : 0x4eb7ff,
          transparent: true,
          opacity: index === 0 ? 0.42 : 0.25,
          depthWrite: false,
        }),
      );
      ring.rotation.x = Math.PI / 2.42;
      ring.rotation.z = index ? -0.25 : 0.18;
      ring.position.y = index ? -0.18 : 0.5;
      root.add(ring);
      orbitRings.push(ring);
    });

    const garmentSpecs = [
      { mesh: createGarment("dress", 0xff3157), radius: 2.95, speed: 0.34, phase: 0.2, y: 0.72, scale: 0.7 },
      { mesh: createGarment("top", 0x63c8ff), radius: 2.58, speed: 0.43, phase: 1.75, y: 1.5, scale: 0.72 },
      { mesh: createGarment("heels", 0xff7892), radius: 2.9, speed: 0.31, phase: 3.35, y: -1.45, scale: 0.72 },
      { mesh: createGarment("jacket", 0x72bdff), radius: 2.68, speed: 0.38, phase: 4.8, y: -0.42, scale: 0.68 },
    ];
    garmentSpecs.forEach(({ mesh, scale }) => {
      mesh.scale.setScalar(scale);
      root.add(mesh);
    });

    const particlesGeometry = new THREE.BufferGeometry();
    const particleCount = 190;
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i += 1) {
      const r = 1.7 + Math.random() * 3.8;
      const a = Math.random() * Math.PI * 2;
      positions[i * 3] = Math.cos(a) * r;
      positions[i * 3 + 1] = -3.25 + Math.random() * 6.7;
      positions[i * 3 + 2] = Math.sin(a) * r * 0.82;
    }
    particlesGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const particles = new THREE.Points(
      particlesGeometry,
      new THREE.PointsMaterial({ color: 0xff3157, size: 0.032, transparent: true, opacity: 0.64, depthWrite: false }),
    );
    root.add(particles);

    scene.add(new THREE.AmbientLight(0x3e2440, 1.4));
    const redLight = new THREE.PointLight(0xff244c, 14, 18);
    redLight.position.set(4.5, 3.5, 5.5);
    scene.add(redLight);
    const blueLight = new THREE.PointLight(0x55bfff, 12, 18);
    blueLight.position.set(-4.5, 1.4, 4.5);
    scene.add(blueLight);
    const rimLight = new THREE.PointLight(0xff7a9a, 9, 16);
    rimLight.position.set(0, -2.5, -4);
    scene.add(rimLight);

    const pointer = { x: 0, y: 0 };
    const onPointerMove = (event: PointerEvent) => {
      const rect = mount.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
      pointer.y = ((event.clientY - rect.top) / rect.height - 0.5) * 2;
    };
    mount.addEventListener("pointermove", onPointerMove);

    const resize = () => {
      const width = Math.max(mount.clientWidth, 1);
      const height = Math.max(mount.clientHeight, 1);
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };
    const observer = new ResizeObserver(resize);
    observer.observe(mount);
    resize();

    const clock = new THREE.Clock();
    let frame = 0;
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const animate = () => {
      const elapsed = clock.getElapsedTime();
      const motion = reduceMotion ? 0.18 : 1;

      mannequin.position.y = 0.12 + Math.sin(elapsed * 0.85) * 0.055 * motion;
      mannequin.rotation.y = Math.sin(elapsed * 0.34) * 0.12 * motion;
      const scan = mannequin.getObjectByName("scan-ring");
      if (scan) scan.position.y = -3.35 + ((elapsed * 1.25) % 6.55);

      garmentSpecs.forEach((spec, index) => {
        const angle = elapsed * spec.speed * motion + spec.phase;
        const depth = Math.sin(angle) * spec.radius * 0.58;
        spec.mesh.position.set(Math.cos(angle) * spec.radius, spec.y + Math.sin(angle * 1.75) * 0.22, depth);
        spec.mesh.rotation.y = -angle + Math.PI / 2;
        spec.mesh.rotation.x = Math.sin(angle * 1.4 + index) * 0.12;
        spec.mesh.rotation.z = Math.cos(angle * 1.1) * 0.08;
        spec.mesh.scale.setScalar(spec.scale * (0.92 + (depth / spec.radius + 1) * 0.07));
      });

      orbitRings[0].rotation.z += 0.0018 * motion;
      orbitRings[1].rotation.z -= 0.0013 * motion;
      particles.rotation.y += 0.0011 * motion;

      root.rotation.y += (pointer.x * 0.075 - root.rotation.y) * 0.035;
      root.rotation.x += (-pointer.y * 0.035 - root.rotation.x - 0.025) * 0.025;
      camera.position.x += (pointer.x * 0.18 - camera.position.x) * 0.025;
      camera.position.y += (-pointer.y * 0.1 + 0.05 - camera.position.y) * 0.025;
      camera.lookAt(0, -0.15, 0);

      renderer.render(scene, camera);
      frame = window.requestAnimationFrame(animate);
    };
    animate();

    return () => {
      window.cancelAnimationFrame(frame);
      observer.disconnect();
      mount.removeEventListener("pointermove", onPointerMove);
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points || object instanceof THREE.LineSegments) {
          object.geometry?.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material?.dispose());
        }
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return <div ref={mountRef} aria-label="Modelo femenino holográfico 3D con prendas orbitando" />;
}
