"use client";

import { useEffect, useMemo, useState } from "react";
import styles from "./ai-tryon-engine-widget.module.css";

const stages = [
  { label: "Análisis corporal", value: "98.7%" },
  { label: "Ajuste de prenda", value: "Óptimo" },
  { label: "Luz y textura", value: "Sincronizado" },
  { label: "Render IA", value: "Listo" },
] as const;

const looks = [
  { code: "01", name: "Vestido", icon: "⌁" },
  { code: "02", name: "Chaqueta", icon: "◇" },
  { code: "03", name: "Top", icon: "◫" },
  { code: "04", name: "Calzado", icon: "⌑" },
] as const;

export function HolographicFashionScene() {
  const [activeStage, setActiveStage] = useState(0);
  const [activeLook, setActiveLook] = useState(1);
  const particles = useMemo(
    () =>
      Array.from({ length: 24 }, (_, index) => ({
        id: index,
        x: `${8 + ((index * 37) % 84)}%`,
        y: `${10 + ((index * 53) % 78)}%`,
        delay: `${(index % 8) * -0.38}s`,
        duration: `${4.8 + (index % 5) * 0.7}s`,
      })),
    [],
  );

  useEffect(() => {
    const stageTimer = window.setInterval(() => {
      setActiveStage((current) => (current + 1) % stages.length);
    }, 1650);
    const lookTimer = window.setInterval(() => {
      setActiveLook((current) => (current + 1) % looks.length);
    }, 3300);

    return () => {
      window.clearInterval(stageTimer);
      window.clearInterval(lookTimer);
    };
  }, []);

  return (
    <div className={styles.widget} aria-label="Motor dinámico de prueba virtual con inteligencia artificial">
      <div className={styles.particles} aria-hidden="true">
        {particles.map((particle) => (
          <span
            key={particle.id}
            style={{
              left: particle.x,
              top: particle.y,
              animationDelay: particle.delay,
              animationDuration: particle.duration,
            }}
          />
        ))}
      </div>

      <div className={styles.hudTop} aria-hidden="true">
        <span><i /> AI TRY-ON ENGINE</span>
        <span>LIVE · 24 FPS</span>
      </div>

      <div className={styles.engine}>
        <div className={styles.inputColumn}>
          <span className={styles.columnLabel}>ENTRADA</span>
          <div className={styles.photoFrame}>
            <div className={styles.cornerOne} />
            <div className={styles.cornerTwo} />
            <div className={styles.person} aria-hidden="true">
              <span className={styles.head} />
              <span className={styles.hair} />
              <span className={styles.neck} />
              <span className={styles.body} />
              <span className={styles.armLeft} />
              <span className={styles.armRight} />
              <span className={styles.legLeft} />
              <span className={styles.legRight} />
            </div>
            <div className={styles.posePoints} aria-hidden="true">
              {Array.from({ length: 9 }, (_, index) => <i key={index} />)}
            </div>
            <span className={styles.inputTag}>FOTO ORIGINAL</span>
          </div>
        </div>

        <div className={styles.processor} aria-hidden="true">
          <div className={styles.beam} />
          <div className={styles.core}>
            <span className={styles.coreRingOne} />
            <span className={styles.coreRingTwo} />
            <span className={styles.coreRingThree} />
            <strong>AI</strong>
            <small>{Math.round(((activeStage + 1) / stages.length) * 100)}%</small>
          </div>
          <div className={styles.dataLineOne} />
          <div className={styles.dataLineTwo} />
        </div>

        <div className={styles.outputColumn}>
          <span className={styles.columnLabel}>RESULTADO</span>
          <div className={styles.photoFrameResult}>
            <div className={styles.resultGlow} />
            <div className={styles.personResult} aria-hidden="true">
              <span className={styles.head} />
              <span className={styles.hair} />
              <span className={styles.neck} />
              <span className={styles.body} />
              <span className={styles.outfit} data-look={activeLook} />
              <span className={styles.armLeft} />
              <span className={styles.armRight} />
              <span className={styles.legLeft} />
              <span className={styles.legRight} />
            </div>
            <div className={styles.scanLine} />
            <span className={styles.outputTag}>LOOK GENERADO</span>
            <span className={styles.match}>98% MATCH</span>
          </div>
        </div>
      </div>

      <div className={styles.lookRail}>
        {looks.map((look, index) => (
          <button
            key={look.code}
            type="button"
            className={index === activeLook ? styles.lookActive : styles.look}
            onClick={() => setActiveLook(index)}
            aria-pressed={index === activeLook}
          >
            <span>{look.icon}</span>
            <small>{look.code}</small>
            <strong>{look.name}</strong>
          </button>
        ))}
      </div>

      <div className={styles.statusPanel}>
        {stages.map((stage, index) => (
          <div key={stage.label} className={index === activeStage ? styles.statusActive : styles.status}>
            <span>{String(index + 1).padStart(2, "0")}</span>
            <div>
              <small>{stage.label}</small>
              <strong>{stage.value}</strong>
            </div>
            <i />
          </div>
        ))}
      </div>
    </div>
  );
}
