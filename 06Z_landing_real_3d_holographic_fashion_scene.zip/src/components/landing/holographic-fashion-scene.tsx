"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

function makeGlowMaterial(color: number, opacity = 0.72) {
  return new THREE.MeshPhysicalMaterial({
    color,
    emissive: color,
    emissiveIntensity: 1.35,
    metalness: 0.18,
    roughness: 0.32,
    transparent: true,
    opacity,
    transmission: 0.08,
    depthWrite: true,
  });
}

function addWireframe(mesh: THREE.Mesh, color = 0xff3659, opacity = 0.38) {
  const wire = new THREE.LineSegments(
    new THREE.WireframeGeometry(mesh.geometry),
    new THREE.LineBasicMaterial({ color, transparent: true, opacity })
  );
  mesh.add(wire);
}

function createLimb(
  radius: number,
  length: number,
  color: number,
  position: THREE.Vector3,
  rotationZ = 0,
) {
  const geometry = new THREE.CapsuleGeometry(radius, length, 8, 16);
  const mesh = new THREE.Mesh(geometry, makeGlowMaterial(color, 0.56));
  mesh.position.copy(position);
  mesh.rotation.z = rotationZ;
  addWireframe(mesh, 0xff6d82, 0.26);
  return mesh;
}

function createMannequin() {
  const group = new THREE.Group();
  group.name = "holographic-mannequin";

  const red = 0xff284f;
  const pink = 0xff6b88;

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.43, 32, 32), makeGlowMaterial(pink, 0.58));
  head.scale.set(0.82, 1.05, 0.82);
  head.position.y = 2.35;
  addWireframe(head, 0xff8aa0, 0.34);
  group.add(head);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.19, 0.34, 18), makeGlowMaterial(red, 0.54));
  neck.position.y = 1.82;
  group.add(neck);

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.65, 1.08, 10, 24), makeGlowMaterial(red, 0.48));
  torso.scale.set(0.92, 1.08, 0.64);
  torso.position.y = 0.98;
  addWireframe(torso, 0xff5472, 0.34);
  group.add(torso);

  const waist = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.58, 0.62, 24), makeGlowMaterial(red, 0.44));
  waist.position.y = 0.03;
  addWireframe(waist, 0xff5472, 0.28);
  group.add(waist);

  const hips = new THREE.Mesh(new THREE.SphereGeometry(0.72, 28, 20), makeGlowMaterial(red, 0.48));
  hips.scale.set(1, 0.62, 0.72);
  hips.position.y = -0.52;
  addWireframe(hips, 0xff5472, 0.28);
  group.add(hips);

  group.add(createLimb(0.16, 0.98, red, new THREE.Vector3(-0.72, 1.1, 0), 0.14));
  group.add(createLimb(0.14, 0.95, red, new THREE.Vector3(-0.89, 0.08, 0), 0.07));
  group.add(createLimb(0.16, 0.98, red, new THREE.Vector3(0.72, 1.1, 0), -0.14));
  group.add(createLimb(0.14, 0.95, red, new THREE.Vector3(0.89, 0.08, 0), -0.07));

  group.add(createLimb(0.22, 1.25, red, new THREE.Vector3(-0.34, -1.42, 0), 0.03));
  group.add(createLimb(0.18, 1.18, red, new THREE.Vector3(-0.36, -2.56, 0), 0.02));
  group.add(createLimb(0.22, 1.25, red, new THREE.Vector3(0.34, -1.42, 0), -0.03));
  group.add(createLimb(0.18, 1.18, red, new THREE.Vector3(0.36, -2.56, 0), -0.02));

  const scan = new THREE.Mesh(
    new THREE.CylinderGeometry(1.05, 1.05, 0.032, 48, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0x8dd7ff,
      transparent: true,
      opacity: 0.8,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }),
  );
  scan.name = "scan-ring";
  group.add(scan);

  return group;
}

function createGarment(kind: "dress" | "top" | "shorts" | "jacket", color: number) {
  const group = new THREE.Group();

  const panel = new THREE.Mesh(
    new THREE.BoxGeometry(1.08, 1.28, 0.09, 4, 4, 1),
    new THREE.MeshPhysicalMaterial({
      color: 0x0a111b,
      emissive: color,
      emissiveIntensity: 0.28,
      metalness: 0.55,
      roughness: 0.28,
      transparent: true,
      opacity: 0.9,
    }),
  );
  panel.rotation.x = -0.08;
  group.add(panel);

  const border = new THREE.LineSegments(
    new THREE.EdgesGeometry(panel.geometry),
    new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.9 }),
  );
  panel.add(border);

  const shape = new THREE.Shape();
  if (kind === "dress") {
    shape.moveTo(-0.2, 0.42); shape.lineTo(0.2, 0.42); shape.lineTo(0.32, 0.08); shape.lineTo(0.48, -0.5); shape.lineTo(-0.48, -0.5); shape.lineTo(-0.32, 0.08); shape.closePath();
  } else if (kind === "top") {
    shape.moveTo(-0.34, 0.36); shape.lineTo(0.34, 0.36); shape.lineTo(0.44, 0.1); shape.lineTo(0.26, -0.34); shape.lineTo(-0.26, -0.34); shape.lineTo(-0.44, 0.1); shape.closePath();
  } else if (kind === "shorts") {
    shape.moveTo(-0.42, 0.28); shape.lineTo(0.42, 0.28); shape.lineTo(0.34, -0.35); shape.lineTo(0.03, -0.2); shape.lineTo(0, -0.35); shape.lineTo(-0.03, -0.2); shape.lineTo(-0.34, -0.35); shape.closePath();
  } else {
    shape.moveTo(-0.24, 0.42); shape.lineTo(0.24, 0.42); shape.lineTo(0.48, 0.16); shape.lineTo(0.33, -0.06); shape.lineTo(0.22, 0.08); shape.lineTo(0.22, -0.46); shape.lineTo(-0.22, -0.46); shape.lineTo(-0.22, 0.08); shape.lineTo(-0.33, -0.06); shape.lineTo(-0.48, 0.16); shape.closePath();
  }

  const icon = new THREE.Mesh(
    new THREE.ShapeGeometry(shape, 6),
    new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.82,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
    }),
  );
  icon.position.z = 0.06;
  icon.scale.setScalar(1.05);
  group.add(icon);

  const halo = new THREE.Mesh(
    new THREE.RingGeometry(0.54, 0.58, 48),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.25, side: THREE.DoubleSide }),
  );
  halo.position.z = -0.01;
  group.add(halo);

  return group;
}

export function HolographicFashionScene() {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
    camera.position.set(0, 0.05, 9.6);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.8));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    mount.appendChild(renderer.domElement);

    const root = new THREE.Group();
    root.rotation.x = -0.03;
    scene.add(root);

    const mannequin = createMannequin();
    mannequin.scale.setScalar(0.88);
    mannequin.position.y = 0.05;
    root.add(mannequin);

    const platform = new THREE.Mesh(
      new THREE.CylinderGeometry(1.58, 1.8, 0.16, 72),
      new THREE.MeshPhysicalMaterial({
        color: 0x16050b,
        emissive: 0xff2047,
        emissiveIntensity: 1,
        metalness: 0.82,
        roughness: 0.2,
        transparent: true,
        opacity: 0.74,
      }),
    );
    platform.position.y = -3.55;
    root.add(platform);

    const platformRing = new THREE.Mesh(
      new THREE.TorusGeometry(1.68, 0.035, 12, 96),
      new THREE.MeshBasicMaterial({ color: 0x67caff, transparent: true, opacity: 0.85 }),
    );
    platformRing.rotation.x = Math.PI / 2;
    platformRing.position.y = -3.44;
    root.add(platformRing);

    const orbitRings: THREE.Mesh[] = [];
    [1.95, 2.65].forEach((radius, index) => {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(radius, 0.018, 8, 128),
        new THREE.MeshBasicMaterial({
          color: index === 0 ? 0xff335a : 0x4eb7ff,
          transparent: true,
          opacity: index === 0 ? 0.45 : 0.28,
          depthWrite: false,
        }),
      );
      ring.rotation.x = Math.PI / 2.45;
      ring.rotation.z = index ? -0.22 : 0.16;
      ring.position.y = index ? -0.1 : 0.45;
      root.add(ring);
      orbitRings.push(ring);
    });

    const garmentSpecs = [
      { mesh: createGarment("dress", 0xff3157), radius: 2.85, speed: 0.38, phase: 0.2, y: 0.9 },
      { mesh: createGarment("top", 0x63c8ff), radius: 2.55, speed: 0.46, phase: 1.8, y: 1.55 },
      { mesh: createGarment("shorts", 0xff6a80), radius: 2.95, speed: 0.33, phase: 3.35, y: -0.65 },
      { mesh: createGarment("jacket", 0x7bbcff), radius: 2.62, speed: 0.41, phase: 4.75, y: -1.5 },
    ];
    garmentSpecs.forEach(({ mesh }) => {
      mesh.scale.setScalar(0.82);
      root.add(mesh);
    });

    const particlesGeometry = new THREE.BufferGeometry();
    const particleCount = 170;
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i += 1) {
      const r = 1.8 + Math.random() * 3.6;
      const a = Math.random() * Math.PI * 2;
      positions[i * 3] = Math.cos(a) * r;
      positions[i * 3 + 1] = -3.2 + Math.random() * 6.5;
      positions[i * 3 + 2] = Math.sin(a) * r * 0.75;
    }
    particlesGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const particles = new THREE.Points(
      particlesGeometry,
      new THREE.PointsMaterial({
        color: 0xff3157,
        size: 0.035,
        transparent: true,
        opacity: 0.65,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    root.add(particles);

    scene.add(new THREE.AmbientLight(0x592536, 1.2));
    const key = new THREE.PointLight(0xff3157, 22, 14);
    key.position.set(-3.8, 2.6, 4.5);
    scene.add(key);
    const rim = new THREE.PointLight(0x4faeff, 18, 15);
    rim.position.set(4.2, 1.2, 2.4);
    scene.add(rim);
    const fill = new THREE.PointLight(0xffffff, 6, 10);
    fill.position.set(0, 4, 4);
    scene.add(fill);

    const pointer = new THREE.Vector2();
    const onPointerMove = (event: PointerEvent) => {
      const rect = mount.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
      pointer.y = -(((event.clientY - rect.top) / rect.height - 0.5) * 2);
    };
    mount.addEventListener("pointermove", onPointerMove);

    const resize = () => {
      const { width, height } = mount.getBoundingClientRect();
      if (!width || !height) return;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(mount);
    resize();

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const clock = new THREE.Clock();
    let frame = 0;

    const animate = () => {
      frame = requestAnimationFrame(animate);
      const t = clock.getElapsedTime();
      const motion = reduceMotion ? 0 : 1;

      mannequin.position.y = 0.05 + Math.sin(t * 1.05) * 0.09 * motion;
      mannequin.rotation.y = Math.sin(t * 0.42) * 0.08 * motion;
      const scanRing = mannequin.getObjectByName("scan-ring");
      if (scanRing) {
        scanRing.position.y = -2.8 + ((t * 1.15) % 5.6);
        scanRing.scale.setScalar(0.82 + Math.sin(t * 2.4) * 0.025);
      }

      garmentSpecs.forEach((spec, index) => {
        const angle = spec.phase + t * spec.speed * motion;
        spec.mesh.position.set(
          Math.cos(angle) * spec.radius,
          spec.y + Math.sin(angle * 1.7 + index) * 0.22 * motion,
          Math.sin(angle) * spec.radius * 0.72,
        );
        spec.mesh.rotation.y = -angle + Math.PI / 2;
        spec.mesh.rotation.z = Math.sin(t * 0.8 + index) * 0.08 * motion;
        const depthScale = 0.72 + ((spec.mesh.position.z / (spec.radius * 0.72) + 1) / 2) * 0.34;
        spec.mesh.scale.setScalar(depthScale);
      });

      orbitRings[0].rotation.z += 0.0018 * motion;
      orbitRings[1].rotation.z -= 0.0013 * motion;
      particles.rotation.y += 0.0011 * motion;
      platformRing.rotation.z += 0.003 * motion;

      root.rotation.y += (pointer.x * 0.11 - root.rotation.y) * 0.035;
      root.rotation.x += (-pointer.y * 0.04 - 0.03 - root.rotation.x) * 0.035;

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(frame);
      mount.removeEventListener("pointermove", onPointerMove);
      resizeObserver.disconnect();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points || object instanceof THREE.LineSegments) {
          object.geometry?.dispose();
          const material = object.material;
          if (Array.isArray(material)) material.forEach((entry) => entry.dispose());
          else material?.dispose();
        }
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return <div ref={mountRef} className="holographic-fashion-canvas" aria-hidden="true" />;
}
