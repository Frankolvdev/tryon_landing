"use client";

import Image from "next/image";
import { useState } from "react";

const looks = ["look-1.jpg","look-2.jpg","look-3.jpg","look-4.jpg","look-5.jpg"];

export function TryOnWidget() {
  const [selected, setSelected] = useState(2);
  return (
    <section className="tryonWidget" aria-label="Demostración interactiva de Try-On">
      <div className="widgetTop"><strong>Live Try-On <em>AI</em></strong><span><i/> Tiempo real</span></div>
      <div className="comparisonGrid">
        <figure><Image src="/images/landing/widget-before.jpg" alt="Modelo antes del cambio de vestuario" fill sizes="(max-width: 700px) 42vw, 160px"/><figcaption>Antes</figcaption></figure>
        <figure><Image src="/images/landing/widget-after.jpg" alt="Modelo después del cambio de vestuario" fill sizes="(max-width: 700px) 42vw, 160px"/><figcaption>Después</figcaption></figure>
        <div className="compareKnob" aria-hidden="true">↔</div>
      </div>
      <div className="lookRail" role="list" aria-label="Seleccionar estilo">
        {looks.map((item,index) => (
          <button key={item} className={selected===index ? "selected" : ""} onClick={() => setSelected(index)} aria-label={`Seleccionar estilo ${index+1}`}>
            <Image src={`/images/landing/${item}`} alt="" fill sizes="52px"/>
          </button>
        ))}
      </div>
      <div className="widgetActions"><button className="generateButton">Generar <span>✦</span></button><button className="adjustButton">Ajustar <span>☷</span></button></div>
    </section>
  );
}
